
#include "../log4z.h"
#include <iostream>
#include <stdio.h>
using namespace zsummer::log4z;

int main(int argc, char *argv[])
{
	//add a logger
	ILog4zManager::GetInstance()->AddLogger(1,"", "AddLogger", LOG_DEBUG, false);
	//change main logger config
	ILog4zManager::GetInstance()->AddLogger(0,"", "main");
	//start log4z
	ILog4zManager::GetInstance()->Start();
	//note fast log
	LOGD(" *** " << "hellow wolrd" <<" *** ");
	LOGI("loginfo");
	LOGW("log warning");
	LOGE("log err");
	LOGA("log alarm");
	LOGF("log fatal");
	//note log that specify the logger and level.
	//fast log is package this method
	LOG_STREAM(1, LOG_DEBUG, "test logger 1");
	//stop log4z
	//ILog4zManager::GetInstance()->Stop();
	printf("press anykey to exit.");
	getchar();
	return 0;
}

