#include "card.h"

sf::RenderWindow* card::pWndw = NULL;
float card::w = 0.0f;
float card::h = 0.0f;

card::card( sf::Image& r_Img, char Suit, int Face )
{
    spr.SetImage( r_Img );
    spr.SetCenter( static_cast<float>( r_Img.GetWidth() )/2.0f, static_cast<float>( r_Img.GetHeight() )/2.0f );
    spr.SetPosition(50.0f, 50.0f);
    suit = Suit;
    face = Face;
}

card::card()
{
    suit='S';
    face = 1;
}

card::~card()
{
    //dtor
}

void card::draw(void)
{
    pWndw->Draw( spr );
    return;
}

bool card::operator<( const card& c ) const
{
    // special cases - NONE

    // all cases
    return face < c.face;
}
