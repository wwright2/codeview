#include "cardStack.h"

float cardStack::dx = 23.0f;
linLeg cardStack::mv_Leg;// for animated card moves
card cardStack::mv_card;// temp for card in transit on mv_Leg
float cardStack::mv_speed = 30.0f;// in pixels / frame

cardStack::cardStack(float X0, float Y0): x0(X0), y0(Y0)
{
    xf = x0;
    mo = false;
    Ncards = 0;
}

cardStack::~cardStack()
{
    //dtor
}


void cardStack::addCard( card newCard )
{
 //   xf = x0 + dx*(float)cards.size();
    newCard.spr.SetPosition( xf, y0 );
    cards.push_back( newCard );
    xf += dx;
    ++Ncards;
}

void cardStack::returnCards( cardStack& r_dest )
{
    while( !cards.empty() )
    {
        r_dest.addCard( cards.back() );
        cards.pop_back();
    }
    Ncards = 0;
    xf = x0;
}
