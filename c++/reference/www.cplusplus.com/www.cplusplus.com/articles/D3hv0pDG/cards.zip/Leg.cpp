#include "Leg.h"

sf::RenderWindow* Leg::pWndw = NULL;

Leg::Leg()
{
    //ctor
}

Leg::~Leg()
{
    //dtor
}

void Leg::move(void)
{
    if( inUse )
    {
        ++tLeg;
        if( tLeg > period )
        {
            tLeg = period;
            inUse = false;
        }
        pSprite->SetPosition( x(tLeg), y(tLeg) );
    }
}

void Leg::draw(void)
{
    pWndw->Draw( *pSprite );
}
