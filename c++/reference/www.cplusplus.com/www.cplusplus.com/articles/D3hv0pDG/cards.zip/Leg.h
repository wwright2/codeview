#ifndef LEG_H
#define LEG_H

#include <SFML/Graphics.hpp>

class Leg
{
    public:

    static sf::RenderWindow* pWndw;
    sf::Sprite* pSprite;

    float period;
    float tLeg;
    bool inUse;

    // functions
	virtual float x( float t ) = 0;
	virtual float y( float t ) = 0;

	void move(void);
	void draw(void);

    Leg();
    virtual ~Leg();
};

#endif // LEG_H
