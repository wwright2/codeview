#ifndef DISCARDSTACK_H
#define DISCARDSTACK_H

#include "cardStack.h"


class discardStack : public cardStack
{
    public:

    int currIdx;// maintained by mseOver()
    int NcardsToSend;

    // functions
    virtual void draw(void);
    virtual bool mseOver(void);
    virtual bool hitLt_dn(void);
    card removeCard(void);
    virtual bool sendCard(cardStack& r_dest);

    discardStack(float X0, float Y0);
    ~discardStack();
};

#endif // DISCARDSTACK_H
