#ifndef DECK_H
#define DECK_H

#include "cardStack.h"


class Deck : public cardStack
{
    public:
    sf::Sprite spr;
    sf::Sprite mv_spr;

    bool TEST;// will deal off top of deck if true (normal deal is a random card in the deck) See removeCard()

    // functions
    virtual void draw(void);// PV in base
    virtual bool mseOver(void);// PV in base
    virtual bool hitLt_dn(void);// PV in base
    virtual card removeCard(void);// PV in base
    virtual bool sendCard(cardStack& r_dest);// PV in base

    virtual void addCard( card newCard );// redef. of base function

    virtual card removeTopCard(void);// so cards can be dealt in a pre-arranged order

    Deck(float X0, float Y0);
    ~Deck();
};

#endif // DECK_H
