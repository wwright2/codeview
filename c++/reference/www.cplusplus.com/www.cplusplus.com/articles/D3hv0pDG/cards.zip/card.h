#ifndef CARD_H
#define CARD_H

#include <SFML/Graphics.hpp>


class card
{
    public:

    static sf::RenderWindow* pWndw;
    static float w;
    static float h;
    sf::Sprite spr;

    char suit;// 'H', 'D', 'S', 'C'
    int face;// 1 - 13 => Ace, 2, 3,..., 10, J, Q, K


    // functions
    void draw(void);
    bool operator<( const card& c ) const;

    card( sf::Image& r_Img, char Suit, int Face );
    card();
    ~card();
};

#endif // CARD_H
