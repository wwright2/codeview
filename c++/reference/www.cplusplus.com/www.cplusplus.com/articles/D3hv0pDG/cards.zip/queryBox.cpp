#include "queryBox.h"

queryBox::queryBox(const sf::Unicode::Text message, float PosX, float PosY)
{
    msg.SetText( message );
    msg.SetFont( sf::Font::GetDefaultFont() );
	msg.SetColor( sf::Color(0,0,0) );
	msg.SetSize( 14.0f );
	msg.SetPosition( PosX + 10.0f, PosY + 10.0f );

	float szX = msg.GetRect().Right + 10.0f > 120.0f ? msg.GetRect().Right + 10.0f : 120.0f;
	float szY = msg.GetRect().Bottom + 50.0f;

    bkgd = sf::Shape::Rectangle( PosX, PosY, szX, szY, sf::Color(0,0,0), 2.0f, sf::Color(0,0,255) );

    yesButt.posX = PosX + 10.0f;
    yesButt.szX = 40.0f;
    yesButt.posY = PosY + szY - 35.0f;
    yesButt.szY = 25.0f;
    yesButt.INITlabel( "YES", 14, sf::Color(0,255,0), 'c' );

    noButt.posX = PosX + szX - 50.0f;
    noButt.szX = 40.0f;
    noButt.posY = PosY + szY - 35.0f;
    noButt.szY = 25.0f;
    noButt.INITlabel( "NO", 14, sf::Color(255,0,0), 'c' );

    open = answer = false;
}

queryBox::~queryBox()
{
    //dtor
}

bool queryBox::hit_dn(void)
{
    bool wasHit = false;// retVal

    if( open )
    {
        if( yesButt.hit() )
        {
            answer = true;
            wasHit = true;
        }
        else if( noButt.hit() )
        {
            answer = false;
            wasHit = true;
        }
        if( wasHit ) open = false;
    }
    return wasHit;
}

void queryBox::mseOver(void)
{
    if( open )
    {
        yesButt.mseOver();
        noButt.mseOver();
    }
    return;
}

void queryBox::draw(void)
{
    if( open )
    {
        yesButt.pWndw->Draw( bkgd );
        yesButt.draw();
        noButt.draw();
    }
    return;
}
