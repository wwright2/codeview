#ifndef OKBOX_H
#define OKBOX_H

#include "buttonRectDrawn.h"


class okBox
{
    public:

    float posX;
    float posY;
    float szX;
    float szY;

    static bool open;// only one okBox can be open at once

    sf::String msg;
    buttonRectDrawn okButt;

    // functions
    void draw(void);

    okBox(float PosX, float PosY, const sf::Unicode::Text Msg);
    bool hit(void);
    bool mseOver(void);

    ~okBox();
};

#endif // OKBOX_H
