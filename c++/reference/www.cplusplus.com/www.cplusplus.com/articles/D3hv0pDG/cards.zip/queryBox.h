#ifndef QUERYBOX_H
#define QUERYBOX_H

#include <SFML/Graphics.hpp>
#include "buttonRectDrawn.h"


class queryBox
{
    public:

    bool open;
    bool answer;
    sf::Shape bkgd;
    sf::String msg;
    buttonRectDrawn yesButt;
    buttonRectDrawn noButt;

    // functions
    bool hit_dn(void);// returns true if either button was hit. get value of answer for user choice.
    void mseOver(void);
    void draw(void);

    queryBox(const sf::Unicode::Text message, float PosX, float PosY);
    ~queryBox();
};

#endif // QUERYBOX_H
