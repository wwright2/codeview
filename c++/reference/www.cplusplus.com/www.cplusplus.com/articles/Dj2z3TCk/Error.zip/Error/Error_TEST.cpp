/*
// Error_TEST.cpp
//
// AUTHORS:     Julius Pettersson
// CREDITS:     n/a
// LCHANGE:     n/a
// PURPOSE:     test driver for Error component
// LICENSE:     Expat/MIT License, see `copying.txt'
//
*/

// custom headers
#include "Error.hpp"

void evil(int i)
{
    ERROR_LOG("evil() function", "evil(%d) says: You passed me a %d, and I dislike you.", i, i);
}

int main()
{
    // ------ UNIT NAME ------ ERROR MESSAGE ------------------------------------------- EXTRA PARAMS
    ERROR_LOG("Welcome 1/4", "This may be annoying, I hope you're ready.");
    ERROR_LOG("Welcome 2/4", "All these messages are saved in a log file in the executable's directory.");
    ERROR_LOG("Welcome 3/4", "%s function %s printf(), and it can take %f arguments!!!", "The logging", "works like", 9000.1f);
    ERROR_LOG("Welcome 4/4", "Just don't put newlines and stuff, they aren't cleared. There, now you have something to improve.");
    evil(55);
    ERROR_LOG("Texture loading failure", "Could not correctly allocate memory. I don't even remember what for."); // realistic error message
    return 0;
}
