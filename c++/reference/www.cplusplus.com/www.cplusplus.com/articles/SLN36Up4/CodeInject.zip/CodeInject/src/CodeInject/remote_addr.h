#include <windows.h>


// not declared in mingw-gcc
#ifndef LIST_MODULES_DEFAULT
  #define LIST_MODULES_DEFAULT 0x0
#endif
#ifndef LIST_MODULES_32BIT
  #define LIST_MODULES_32BIT 0x01
#endif
#ifndef LIST_MODULES_64BIT
  #define LIST_MODULES_64BIT 0x02
#endif
#ifndef LIST_MODULES_ALL
  #define LIST_MODULES_ALL (LIST_MODULES_32BIT|LIST_MODULES_64BIT)
#endif



//
// EnumProcessEx is not linked under gcc-mingw
//
typedef BOOL (*WINAPI FpEnumProcessModulesEx)(
   HANDLE hProcess,
   HMODULE *lphModule,
   DWORD cb,
   LPDWORD lpcbNeeded,
   DWORD dwFilterFlag
);




// NOTE: these functions are from:
// http://www.codeproject.com/Tips/139349/Getting-the-address-of-a-function-in-a-DLL-loaded?display=Print

// Equivalent to GetModuleHandle
HMODULE WINAPI GetRemoteModuleHandle(HANDLE hProcess, LPCSTR lpModuleName);
// Equivalent to GetProceAddress
FARPROC WINAPI GetRemoteProcAddress (HANDLE hProcess, HMODULE hModule, LPCSTR lpProcName, UINT Ordinal, BOOL UseOrdinal);
