#include <iostream>

using namespace std;

int main()
{
    cout <<"Hello world!" << endl;
    cout <<"This is a test application. Try to inject DLL into it!"<<endl;
    cout <<"Enter q to quit";

    string s;
    while(s!="q")
    {
      getline(cin,s);
    }

    return 0;
}
