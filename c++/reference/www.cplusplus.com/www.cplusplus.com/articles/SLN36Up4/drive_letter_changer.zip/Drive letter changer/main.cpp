#define _WIN32_WINNT 0x500

#include <iostream>
#include <windows.h>
using namespace std;

int main()
{
  string new_mountpoint,
  old_mountpoint;

  char unc_path[512]; // UNC path is needed to mount a device


  cout <<"Enter the old drive letter (A...Z): ";
  cin >>old_mountpoint;

  cout <<"Enter the new drive letter (A...Z): ";
  cin >>new_mountpoint;

  old_mountpoint+=":\\";
  new_mountpoint+=":\\";

  if(!GetVolumeNameForVolumeMountPoint(old_mountpoint.c_str(),unc_path,512))
    {
      cout <<"GetVolumeMountPoint() error. Error code: "<<GetLastError()<<endl;
      return 1;
    }

 // clog <<"UNC path of the disk: "<<unc_path<<endl;

  if(!DeleteVolumeMountPoint(old_mountpoint.c_str()))
    {
      cout <<"DeleteVolumeMountPoint() error. Error code: "<<GetLastError()<<endl;
      return 1;
    }

  if(!SetVolumeMountPoint(new_mountpoint.c_str(),unc_path))
    {
      cout <<"SetVolumeMountPoint() error. Error code: "<<GetLastError()<<endl;
      return 1;
    }

  cout <<"Done!"<<endl;


  return 0;
}
