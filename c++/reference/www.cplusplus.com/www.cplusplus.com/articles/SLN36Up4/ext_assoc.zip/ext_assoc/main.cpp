#include <windows.h>
#include <iostream>
using namespace std;

int main(int argc, char *argv[])
{
  HKEY hkey;

  string extension;
  string app;
  string action; // a short description (eg. open with x.exe)

  cout <<"Enter file extension: .";
  cin >>extension;
  cin.ignore();

  cout <<"Enter a short description (eg. open with x.exe) ";
  getline(cin,action);

  cout <<"Enter path to the application (eg C:\\x.exe) ";
  getline(cin,app);

  extension=string(".")+extension;
  app=app+" \"%1\""; // pass file path as 1st argument to the program

  string path=extension+
              string("\\shell\\")+
              action+
              "\\command\\";

// 1: Create a registry key for extension ( HKEY_CLASSES_ROOT\[extension]\ )
  if(RegCreateKeyEx(HKEY_CLASSES_ROOT,extension.c_str(),0,0,0,KEY_ALL_ACCESS,0,&hkey,0)!=ERROR_SUCCESS)
    {
      std::cerr <<"Could not create or open a registrty key\n";
      return 1;
    }
  RegCloseKey(hkey);


// 2: Create subkeys
//    HKEY_CLASSES_ROOT\[extension]\shell\[action]\command\
//    'default' key is the path to the program
  if(RegCreateKeyEx(HKEY_CLASSES_ROOT,path.c_str(),0,0,0,KEY_ALL_ACCESS,0,&hkey,0)!=ERROR_SUCCESS)
    {
      std::cerr <<"Could not create or open a registry key\n";
      return 1;
    }
  RegSetValueEx(hkey,"",0,REG_SZ,(BYTE*)app.c_str(),app.length());
  RegCloseKey(hkey);

  return 0;
}
