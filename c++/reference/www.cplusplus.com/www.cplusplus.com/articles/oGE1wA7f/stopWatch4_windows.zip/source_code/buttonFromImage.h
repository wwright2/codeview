#ifndef BUTTONFROMIMAGE_H
#define BUTTONFROMIMAGE_H

#include "button.h"

class buttonFromImage :	public button
{
public:
	sf::Image* pImg;
	sf::Sprite* pSprite;
	int szX;
	int szY;

	// functions
	virtual bool hit(void);
	virtual void draw(void);
	void INITlabel(const sf::Unicode::Text Label, int fontSize, sf::Color txtColor, char labelPos);
	void assign_Sprite(sf::Sprite* p_Sprite);

	buttonFromImage(int PosX, int PosY, int SzX, int SzY, sf::Sprite* p_Sprite = NULL);
	buttonFromImage(int PosX, int PosY);
//	buttonFromImage(void);
	~buttonFromImage(void);
};

#endif // BUTTONFROMIMAGE_H
