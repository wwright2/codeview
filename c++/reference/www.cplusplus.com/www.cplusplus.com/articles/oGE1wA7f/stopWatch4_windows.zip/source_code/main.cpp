
#include <windows.h>
#include <SFML/Graphics.hpp>
#include<vector>
//#include <tchar.h>
//#include <stdlib.h>

#include "button.h"
#include "buttonFromImage.h"

using std::vector;

LRESULT CALLBACK WndProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam);

HDC hdc;

sf::Image bkgdImg;
sf::Sprite bkgdSprite;
sf::Image buttImg1;
sf::Sprite buttSprite1;

//** buttons **
sf::RenderWindow* button::pWndw = NULL;
int button::mseX = 0;
int button::mseY = 0;
// mode selection
buttonFromImage clockModeButt(35, 200);
buttonFromImage statModeButt(135, 200);
// for clock mode
buttonFromImage startButt(35, 80);// top section
buttonFromImage resetButt(135, 80);

buttonFromImage  newButt(35, 130);// trials section
buttonFromImage prevButt(85, 130);
buttonFromImage nextButt(135, 130);
buttonFromImage deleteButt(85, 160);
buttonFromImage deleteAllButt(135, 160);

buttonFromImage minButt(35, 130);// for stats mode
buttonFromImage maxButt(85, 130);
buttonFromImage totalButt(135, 130);
buttonFromImage avgButt(85, 160);
buttonFromImage stdDevButt(135, 160);

// graphic objects
sf::Shape bkRect1 = sf::Shape::Rectangle(17.f, 25.f, 183.f, 53.f, sf::Color(0,255,102), 4.f, sf::Color(100,0,0));
sf::Shape TRect = sf::Shape::Rectangle(40.f, 160.f, 60.f, 180.f, sf::Color(0,255,102), 2.f, sf::Color(100,0,0));
sf::Shape Line1   = sf::Shape::Line(5.0f, 110.0f, 195.0f, 110.0f, 3.0f, sf::Color(0,0,0) );
sf::Shape Line2   = sf::Shape::Line(5.0f, 190.0f, 195.0f, 190.0f, 3.0f, sf::Color(0,0,0) );
sf::String timeText;// variable
sf::String trialText;
sf::String trialDigit;// variable
sf::String NtrialsText;
sf::String NtrialsDigit;// variable
sf::String modeMessage;
sf::String sectionLabel;
sf::String modeLabel;

// mode control - 'c'=clock, 's'=stats
char chMode = 'c';// determines what is drawn and which buttons are active

// the clock
sf::Clock frClock;
float ElapsedTime = 0.0f;
float prevTime = 0.0f;

// trials variables
vector<float> trialVec( 1, 0.0f );// trial times stored here
vector<float>::iterator trialVecIter = trialVec.begin();
int Ntrials = trialVec.size();
void IntToString(sf::String& rStr, int val);
int currTrial = 1;

// my global functions
void INITall(void);
void timeToString(float timeVal);
void IntToString(sf::String& rStr, int val);
void centerString(sf::String& rStr, float Xcenter);
void mouseOverAll(void);
void hitLeftClockButts(void);
void hitLeftStatButts(void);

int APIENTRY WinMain(HINSTANCE hinst,
                     HINSTANCE hPrevInstance,
                     LPSTR     lpCmdLine,
                     int       nCmdShow)
{
	HWND hwnd;
	MSG  lpmsg;
	memset(&lpmsg,0,sizeof(lpmsg));
	WNDCLASSEX wc = {0};
	static char szAppName[] = "StopWatch";

	wc.cbSize = sizeof(WNDCLASSEX);
	wc.lpszClassName = szAppName;
	wc.hInstance = hinst;
	wc.lpfnWndProc = WndProc;
	wc.hCursor = LoadCursor(NULL, IDC_ARROW);
	wc.hIcon = LoadIcon(NULL, IDI_APPLICATION);
	wc.hIconSm = LoadIcon(NULL,IDI_APPLICATION);
	wc.lpszMenuName = 0;
	wc.hbrBackground =  reinterpret_cast<HBRUSH>(GetStockObject(WHITE_BRUSH));
	wc.style = CS_HREDRAW | CS_VREDRAW;
	wc.style = CS_GLOBALCLASS;
	wc.cbClsExtra = 0;
	wc.cbWndExtra = 0;
	if( !RegisterClassEx (&wc) )
		return 0;

	// create the main window
	hwnd = CreateWindow(szAppName, "stop watch", WS_SYSMENU | WS_VISIBLE | WS_MINIMIZEBOX,
		200, 200, 206, 262, NULL, NULL, hinst, NULL);

	// create one SFML view
	DWORD Style = WS_CHILD | WS_VISIBLE | WS_CLIPSIBLINGS;
	HWND  View1 = CreateWindow( "STATIC", NULL, Style, 0,  0, 200, 230, hwnd, NULL, hinst, NULL);

	sf::RenderWindow App(View1);

	// INIT stuff
	button::pWndw = &App;
	frClock.Reset();
	INITall();

	ShowWindow(hwnd, nCmdShow);
	UpdateWindow(hwnd);

	App.UseVerticalSync(true);// default = false

	while( lpmsg.message != WM_QUIT )
	{
		if( PeekMessage( &lpmsg, NULL, 0, 0, PM_REMOVE ) )
		{
			TranslateMessage( &lpmsg );
			DispatchMessage( &lpmsg );
		}
        else
		{
			// measure time
			if( startButt.sel )// clock is running
			{
				ElapsedTime = frClock.GetElapsedTime() + prevTime;
				timeToString(ElapsedTime);
			}

			// Clear the screen
			App.Clear( sf::Color(102, 153, 204) );// too blue

			// draw stuff
			App.Draw(bkgdSprite);
			App.Draw(bkRect1);
			App.Draw(TRect);

			App.Draw(NtrialsText);
			App.Draw(NtrialsDigit);// var
			App.Draw( modeMessage );
			App.Draw( sectionLabel );
			App.Draw( modeLabel );

			App.Draw(Line1);
			App.Draw(Line2);

			clockModeButt.draw();
			statModeButt.draw();

			if( chMode == 'c' )// clock mode
			{
				// text
				App.Draw(timeText);// var
				App.Draw(trialText);
				App.Draw(trialDigit);// var
				// buttons
				startButt.draw();
				resetButt.draw();
				newButt.draw();
				prevButt.draw();
				nextButt.draw();
				deleteButt.draw();
				deleteAllButt.draw();
			}
			else if( chMode == 's' )// stats mode
			{
				minButt.draw();
				maxButt.draw();
				totalButt.draw();
				avgButt.draw();
				stdDevButt.draw();
				if( minButt.sel || maxButt.sel )// when min or max
				{
					App.Draw(trialText);
					App.Draw(trialDigit);// var
				}
				if( minButt.sel || maxButt.sel || totalButt.sel || avgButt.sel || stdDevButt.sel )
				App.Draw(timeText);// var
			}

			App.Display();
		}// end else render
	}
	UnregisterClass( szAppName, wc.hInstance );

	return(lpmsg.wParam);
 	// TODO: Place code here.
}// end of WinMain()

LRESULT CALLBACK WndProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
	switch(msg)
	{
		case WM_DESTROY:
			PostQuitMessage(0);
			break;
		case WM_LBUTTONDOWN:
			if( clockModeButt.hit() )
			{
				if( chMode != 'c' )// assigns made when entering clock mode
				{
					chMode = 'c';// clock mode
					// restore text
					modeMessage.SetText("clock mode"); centerString(modeMessage,100.0f);
					sectionLabel.SetText("trials"); centerString(sectionLabel,100.0f);
					IntToString( trialDigit, currTrial );
					timeToString(ElapsedTime);
					minButt.sel = false;
					maxButt.sel = false;
					totalButt.sel = false;
					avgButt.sel = false;
					stdDevButt.sel = false;
					statModeButt.sel = false;
					clockModeButt.sel = true;
					clockModeButt.mo = false;
				}
				return true;
			}
			if( Ntrials > 1 && !startButt.sel )// stat mode avail when multiple trials and clock stopped
				if( statModeButt.hit() )
				{
					if( chMode != 's' )// don't repeat below if already in stat mode
					{
						modeMessage.SetText("stats mode"); centerString(modeMessage,100.0f);
						sectionLabel.SetText("function"); centerString(sectionLabel,100.0f);
						chMode = 's';// stats mode
						clockModeButt.sel = false;
						statModeButt.sel = true;
						statModeButt.mo = false;
					}
					return true;
				}

			if( chMode == 'c' )
				hitLeftClockButts();
			else if( chMode == 's' )
				hitLeftStatButts();

			break;
		case WM_LBUTTONUP:
			if( chMode == 'c' )// clock mode
				if( resetButt.hit() )
					resetButt.sel = false;// so button acts as a 'momentary contact' type

			break;
		case WM_MOUSEMOVE:
			button::mseX = LOWORD (lParam);
			button::mseY = HIWORD (lParam);
			mouseOverAll();
			// sliding off of resetButt releases it
			if( !resetButt.mo )
				resetButt.sel = false;// also a 'momentary contact' behavior

			break;
		default:
			return( DefWindowProc(hwnd, msg, wParam, lParam) );
			break;
	}//End Switch on msg.
	return(0);
}//End CALLBACK.

void INITall(void)
{
	// images and sprites
	bkgdImg.LoadFromFile("bkgdImage.png");
	bkgdSprite.SetImage(bkgdImg);
	bkgdSprite.SetPosition(0.0f, 0.0f);

	buttImg1.LoadFromFile( "buttonsImage.png" );
	buttImg1.CreateMaskFromColor( sf::Color(0,0,0) );
	buttSprite1.SetImage( buttImg1 );

	// button labels
    startButt.assign_Sprite( &buttSprite1 );         startButt.INITlabel( "start", 12, sf::Color(0,0,0), 'c' );
	resetButt.assign_Sprite( &buttSprite1 );         resetButt.INITlabel( "reset", 12, sf::Color(0,0,0), 'c' );
	newButt.assign_Sprite( &buttSprite1 );             newButt.INITlabel( "new", 12, sf::Color(0,0,0), 'c' );
	prevButt.assign_Sprite( &buttSprite1 );           prevButt.INITlabel( "prev", 12, sf::Color(0,0,0), 'c' );
	nextButt.assign_Sprite( &buttSprite1 );           nextButt.INITlabel( "next", 12, sf::Color(0,0,0), 'c' );
	deleteButt.assign_Sprite( &buttSprite1 );       deleteButt.INITlabel( "delete", 10, sf::Color(0,0,0), 'c' );
	deleteAllButt.assign_Sprite( &buttSprite1 ); deleteAllButt.INITlabel( "dltAll", 10, sf::Color(0,0,0), 'c' );
	minButt.assign_Sprite( &buttSprite1 );             minButt.INITlabel( "min", 12, sf::Color(0,0,0), 'c' );
	maxButt.assign_Sprite( &buttSprite1 );             maxButt.INITlabel( "max", 12, sf::Color(0,0,0), 'c' );
	totalButt.assign_Sprite( &buttSprite1 );         totalButt.INITlabel( "total", 12, sf::Color(0,0,0), 'c' );
	avgButt.assign_Sprite( &buttSprite1 );             avgButt.INITlabel( "avg", 12, sf::Color(0,0,0), 'c' );
	stdDevButt.assign_Sprite( &buttSprite1 );       stdDevButt.INITlabel( "stdev", 10, sf::Color(0,0,0), 'c' );
	clockModeButt.assign_Sprite( &buttSprite1 ); clockModeButt.INITlabel( "SW", 12, sf::Color(0,0,0), 'c' );
	clockModeButt.sel = true;// 'clock mode' initially selected
	statModeButt.assign_Sprite( &buttSprite1 );   statModeButt.INITlabel( "stat", 12, sf::Color(0,0,0), 'c' );

	// time text
	timeText.SetText("00:00:00.00");
	timeText.SetFont( sf::Font::GetDefaultFont() );
	timeText.SetColor(sf::Color(0, 0, 255));
	timeText.SetPosition(24.f, 20.f);

	// trialText - constant
	trialText.SetText("trial");
	trialText.SetFont( sf::Font::GetDefaultFont() );
	trialText.SetSize(15.f);
	trialText.SetColor(sf::Color(0, 0, 0));
	trialText.SetPosition(75.f, 3.f);
	// trialDigit - variable
	trialDigit.SetText("1");
	trialDigit.SetFont( sf::Font::GetDefaultFont() );
	trialDigit.SetSize(15.f);
	trialDigit.SetColor(sf::Color(0, 0, 0));
	trialDigit.SetPosition(100.f, 3.f);

	// Ntrials text - constant
	NtrialsText.SetText("trials");
	NtrialsText.SetFont( sf::Font::GetDefaultFont() );
	NtrialsText.SetSize(12.f);
	NtrialsText.SetColor(sf::Color(0, 0, 0));
	NtrialsText.SetPosition(5.f, 160.f);
	// NtrialsDigit - variable
	NtrialsDigit.SetText("1");
	NtrialsDigit.SetFont( sf::Font::GetDefaultFont() );
	NtrialsDigit.SetSize(16.f);
	NtrialsDigit.SetColor(sf::Color(0, 0, 0));
	NtrialsDigit.SetPosition(45.f, 160.f);

	// mode message - below display
	modeMessage.SetText("clock mode");
	modeMessage.SetFont( sf::Font::GetDefaultFont() );
	modeMessage.SetSize(16.f);
	modeMessage.SetColor(sf::Color(0, 0, 0));
	modeMessage.SetPosition(55.f, 55.f);
	centerString(modeMessage,100.0f);

	// button function label = "trials" or "function"
	sectionLabel.SetText("trials");
	sectionLabel.SetFont( sf::Font::GetDefaultFont() );
	sectionLabel.SetSize(14.f);
	sectionLabel.SetColor(sf::Color(0, 0, 0));
	sectionLabel.SetPosition(75.f, 110.f);
	centerString(sectionLabel,100.0f);
	modeLabel.SetText("mode");
	modeLabel.SetFont( sf::Font::GetDefaultFont() );
	modeLabel.SetSize(14.f);
	modeLabel.SetColor(sf::Color(0, 0, 0));
	modeLabel.SetPosition(80.f, 190.f);
	centerString(modeLabel,100.0f);


	return;
}// end of INITall()

void timeToString(float timeVal)
{
	static char chTime[12] = "00:00:00.00";
//	int bigSecs = static_cast<int>( 100.0f*ElapsedTime );
	int bigSecs = static_cast<int>( 100.0f*timeVal );// bigSecs = 100 * actual seconds


	// hours
	bigSecs %= 8640000;// 24 hours
	chTime[0] = '0' + bigSecs/3600000;// tens of hours
	bigSecs %= 3600000;
	chTime[1] = '0' + bigSecs/360000;// one hour
	chTime[2] = ':';

	// minutes
	bigSecs %= 360000;// 60 minute
	chTime[3] = '0' + bigSecs/60000;// tens of minutes
	bigSecs %= 60000;
	chTime[4] = '0' + bigSecs/6000;// minutes
	chTime[5] = ':';

	// whole seconds
	bigSecs %= 6000;// 60 seconds
	chTime[6] = '0' + bigSecs/1000;// tens of seconds
	bigSecs %= 1000;
	chTime[7] = '0' + bigSecs/100;// seconds
	chTime[8] = '.';

	// hundredths of seconds
	bigSecs %= 100;
	chTime[9] = '0' + bigSecs/10;
	bigSecs %= 10;
	chTime[10] = '0' + bigSecs;
	chTime[11] = '\0';

	// assign to text
	timeText.SetText( chTime );

	return;
}// end of timeToString()

void IntToString(sf::String& rStr, int val)
{
	static char chInt[20] = "01";
	static char chIntRev[20] = "aaaaaaaaaaaaaaaaaaa";

	int Dcount = 0;
	do
	{
		chIntRev[Dcount] = val%10 + '0';
		Dcount++;
		val /= 10;
	}while(val && Dcount<20);

	for(int i=0; i<Dcount; i++)
		chInt[i] = chIntRev[Dcount-1-i];
	chInt[Dcount] = '\0';

	// assign to text
	rStr.SetText( chInt );

	return;
}// end of IntToString()

void centerString(sf::String& rStr, float Xcenter)
{
	sf::FloatRect strRect = rStr.GetRect();
	float len = strRect.Right - strRect.Left;
	rStr.SetX( Xcenter - len/2.0f );
	return;
}

void mouseOverAll(void)
{
	// clock mode buttons
	if( chMode == 'c' )
	{
		startButt.mseOver();
		resetButt.mseOver();
		newButt.mseOver();
		if( Ntrials > 1 && !startButt.sel )
		{
			if( currTrial > 1 )
				prevButt.mseOver();
			if( currTrial < Ntrials )
				nextButt.mseOver();
			deleteButt.mseOver();
			deleteAllButt.mseOver();
			// stat mode available
			statModeButt.mseOver();
		}
	}
	else if( chMode == 's' )// stat mode
	{
		// stat mode buttons
		minButt.mseOver();
		maxButt.mseOver();
		totalButt.mseOver();
		avgButt.mseOver();
		stdDevButt.mseOver();
		// clock mode available
		clockModeButt.mseOver();
	}

	return;
}// end of mouseOverAll()

void hitLeftClockButts(void)
{
	if( startButt.hit() )
	{
		if( startButt.sel )// stop the clock
		{
			startButt.sel = false;
		//	startButt.INITlabel( "start", 3, 2, 12, sf::Color(0,0,0) );// indicates next function of button
			startButt.INITlabel( "start", 12, sf::Color(0,0,0), 'c' );
			prevTime = ElapsedTime;
			*trialVecIter = ElapsedTime;// save time for present trial
		}
		else// start the clock
		{
			startButt.sel = true;
		//	startButt.INITlabel( "stop", 4, 2, 12, sf::Color(0,0,0) );
			startButt.INITlabel( "stop", 12, sf::Color(0,0,0), 'c' );
			frClock.Reset();
		}
	}

	if( resetButt.hit() )
	{
		resetButt.sel = true;
		frClock.Reset();
		ElapsedTime = 0.0f;
		prevTime = 0.0f;
		*trialVecIter = ElapsedTime;// save time for present trial
		timeToString(ElapsedTime);
	}

	// changing Ntrials
	if( newButt.hit() )
	{
		*trialVecIter = ElapsedTime;// save time for present trial
		trialVec.push_back(0.0f);
		trialVecIter = trialVec.end() - 1;// -1 ??
		Ntrials = trialVec.size();// Ntrials should get incremented
		frClock.Reset();
		ElapsedTime = 0.0f;
		prevTime = 0.0f;
		IntToString( NtrialsDigit, Ntrials );
		currTrial = Ntrials;
		IntToString( trialDigit, currTrial );
		timeToString(ElapsedTime);// update display
	}
	// next 4 buttons - prev, next, delete and delete all should take no hits while clock running
	if( !startButt.sel )
	{
		if( deleteButt.hit() )
		{
			if( Ntrials > 1 )
			{
				trialVec.erase( trialVec.begin() + currTrial - 1 );
				Ntrials = trialVec.size();// Ntrials should get decremented
				IntToString( NtrialsDigit, Ntrials );
				if( currTrial > Ntrials )
					currTrial = Ntrials;

				trialVecIter = trialVec.begin() + currTrial - 1;
				IntToString( trialDigit, currTrial );
				ElapsedTime = *trialVecIter;
				prevTime = ElapsedTime;
				timeToString(ElapsedTime);// update display

				if( Ntrials == 1 )deleteButt.mo = false;
			}
		}
		if( deleteAllButt.hit() )
		{
			trialVec.clear();
			trialVec.push_back(0.0f);
			trialVecIter = trialVec.begin();
			Ntrials = 1;
			IntToString( NtrialsDigit, Ntrials );
			currTrial = 1;
			IntToString( trialDigit, currTrial );
			prevTime = 0.0f;
			ElapsedTime = 0.0f;
			timeToString(ElapsedTime);// update display
			deleteAllButt.mo = false;
		}

		// changing currTrial
		if( prevButt.hit() )
		{
			if( currTrial > 1 )
			{
				trialVecIter--;
				prevTime = ElapsedTime = *trialVecIter;
				currTrial--;
				IntToString( trialDigit, currTrial );
				timeToString(ElapsedTime);// update display
			}
			if( currTrial == 1 )prevButt.mo = false;
		}
		if( nextButt.hit() )
		{
			if( currTrial < Ntrials )
			{
				trialVecIter++;
				prevTime = ElapsedTime = *trialVecIter;
				currTrial++;
				IntToString( trialDigit, currTrial );
				timeToString(ElapsedTime);// update display
			}
			if( currTrial == Ntrials )nextButt.mo = false;
		}
	}// end if clock not running
	return;
}// end of hitLeftClockButts()

void hitLeftStatButts(void)
{
	minButt.sel = false;
	maxButt.sel = false;
	totalButt.sel = false;
	avgButt.sel = false;
	stdDevButt.sel = false;

	if( minButt.hit() )
	{
		float minTime = trialVec.at(0);
		int trialNum = 1;
		for( int i = 0; i < Ntrials; i++ )
			if( trialVec.at(i) < minTime )
			{
				minTime = trialVec.at(i);
				trialNum = i + 1;
			}
		modeMessage.SetText("lowest time");
		IntToString( trialDigit, trialNum );
		timeToString(minTime);
		minButt.sel = true;
	}
	if( maxButt.hit() )
	{
		float maxTime = trialVec.at(0);
		int trialNum = 1;
		for( int i = 0; i < Ntrials; i++ )
			if( trialVec.at(i) > maxTime )
			{
				maxTime = trialVec.at(i);
				trialNum = i + 1;
			}
		modeMessage.SetText("greatest time");
		IntToString( trialDigit, trialNum );
		timeToString(maxTime);
		maxButt.sel = true;
	}
	if( totalButt.hit() )
	{
		float totTime = 0.0;
		for( vector<float>::iterator iter = trialVec.begin(); iter != trialVec.end(); iter++ )
			totTime += *iter;
		modeMessage.SetText("total time");
		timeToString(totTime);
		totalButt.sel = true;
	}
	if( avgButt.hit() )
	{
		float avgTime = 0.0;
		for( vector<float>::iterator iter = trialVec.begin(); iter != trialVec.end(); iter++ )
			avgTime += *iter;
		avgTime /= Ntrials;
		modeMessage.SetText("average time");
		timeToString(avgTime);
		avgButt.sel = true;
	}
	if( stdDevButt.hit() )
	{
		// find average value
		float avgTime = 0.0;
		for( vector<float>::iterator iter = trialVec.begin(); iter != trialVec.end(); iter++ )
			avgTime += *iter;
		avgTime /= Ntrials;
		// find variance
		float var = 0.0f;
		for( vector<float>::iterator iter = trialVec.begin(); iter != trialVec.end(); iter++ )
			var += ( *iter - avgTime )*( *iter - avgTime );
		var /= Ntrials;
		timeToString( sqrt(var) );// standard deviation = sqrt( variance )
		modeMessage.SetText("standard deviation");
		stdDevButt.sel = true;
	}
	centerString(modeMessage,100.0f);
	return;
}// end of hitLeftStatButts()
