
#include "buttonFromImage.h"

buttonFromImage::buttonFromImage(int PosX, int PosY, int SzX, int SzY, sf::Sprite* p_Sprite ):button(PosX, PosY)
{
	pSprite = p_Sprite;
	szX = SzX;
	szY = SzY;
}

buttonFromImage::buttonFromImage(int PosX, int PosY):button(PosX, PosY)
{
    pSprite = NULL;
	szX = 5;
	szY = 5;
}

buttonFromImage::~buttonFromImage(void)
{
}

void buttonFromImage::assign_Sprite(sf::Sprite* p_Sprite)
{
    pSprite = p_Sprite;
    const sf::Image* pImg = pSprite->GetImage();
    if( pImg )
    {
        szX = pImg->GetWidth()/2;
        szY = pImg->GetHeight()/2;
    }
}

bool buttonFromImage::hit(void)
{
	if( (mseX > posX) && (mseX < posX+szX) && (mseY > posY) && (mseY < posY+szY) )
		return true;
	return false;
}

void buttonFromImage::draw(void)
{
	sf::IntRect srcRect;
	srcRect.Top = sel ? szY+1 : 0;
	srcRect.Left = mo ? szX+1 : 0;
	srcRect.Bottom = srcRect.Top  + szY;
	srcRect.Right = srcRect.Left + szX;
	pSprite->SetSubRect(srcRect);
	pSprite->SetPosition( static_cast<float>(posX), static_cast<float>(posY) );

	if( pWndw )
	{
		pWndw->Draw( *pSprite );
		pWndw->Draw( label );
	}
	return;
}

void buttonFromImage::INITlabel(const sf::Unicode::Text Label, int fontSize, sf::Color txtColor, char labelPos)
{
	float fposX = static_cast<float>(posX);// fix this!
	float fposY = static_cast<float>(posY);
	float fszX = static_cast<float>(szX);
	float fszY = static_cast<float>(szY);

	label.SetText(Label);
	label.SetFont( sf::Font::GetDefaultFont() );
	label.SetColor(txtColor);
	label.SetPosition( fposX, fposY );
	label.SetSize( static_cast<float>(fontSize) );

	sf::FloatRect sR = label.GetRect();
	float len = sR.GetWidth();
	float hgt = sR.GetHeight();

	switch(labelPos)
	{
	case 'c':// centered
		label.SetX( (2.0f*fposX + fszX - len)/2.0f );
		label.SetY( (2.0f*fposY + fszY - hgt)/2.0f - 1.5f );
		break;
	case 'l':// left side
		label.SetX( fposX - len - 3.0f );
		label.SetY( (2.0f*fposY + fszY - hgt)/2.0f - 1.5f );
		break;
	case 'r':// right side
		label.SetX( fposX +fszX + 3.0f );
		label.SetY( (2.0f*fposY + fszY - hgt)/2.0f - 1.5f );
		break;
	case 't':// on top
		label.SetX( (2.0f*fposX + fszX - len)/2.0f );
		label.SetY( fposY - hgt - 3.0f );
		break;
	case 'b':// below
		label.SetX( (2.0f*fposX + fszX - len)/2.0f );
		label.SetY( fposY +fszY - 1.0f );
		break;
	default:
		break;
	}

	return;
}// end of INITlabel()

