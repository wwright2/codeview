
#include "button.h"

button::button(void)
{
	posX = 0;
	posY = 0;
	sel = false;
	mo = false;
}

button::button(int PosX, int PosY)
{
	posX = PosX;
	posY = PosY;
	sel = false;
	mo = false;
}

button::~button(void)
{
}

bool button::mseOver(void)
{
	if( hit() )
		mo = true;
	else
		mo = false;
	return mo;
}
