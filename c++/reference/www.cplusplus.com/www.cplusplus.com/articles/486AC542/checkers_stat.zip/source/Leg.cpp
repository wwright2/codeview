#include "Leg.h"

Leg::Leg()
{
    //ctor
}

Leg::~Leg()
{
    //dtor
}
